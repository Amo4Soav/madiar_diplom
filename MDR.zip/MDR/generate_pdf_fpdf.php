<?php
require_once 'config.php';
require_once('fpdf/fpdf.php'); // Требуется скачать FPDF с официального сайта

class DocumentGenerator {
    private $pdf;
    
    public function __construct() {
        $this->pdf = new FPDF();
        $this->pdf->AddPage();
        $this->pdf->SetFont('Arial', '', 12);
    }
    
    // Генерация заявления на удостоверение личности
    public function generateUdastakApplication($userData) {
        $this->pdf->SetTitle('Заявление на получение удостоверения личности');
        
        // Заголовок
        $this->pdf->SetFont('Arial', 'B', 16);
        $this->pdf->Cell(0, 10, 'ЗАЯВЛЕНИЕ', 0, 1, 'C');
        $this->pdf->SetFont('Arial', '', 12);
        $this->pdf->Cell(0, 10, 'на получение удостоверения личности', 0, 1, 'C');
        $this->pdf->Ln(10);
        
        // Основной текст
        $this->pdf->MultiCell(0, 10, 'Я, ' . $userData['full_name'] . ', прошу выдать мне удостоверение личности.', 0, 'L');
        $this->pdf->Ln(5);
        
        // Личные данные
        $this->pdf->MultiCell(0, 10, 'ИИН: ' . $userData['iin'], 0, 'L');
        $this->pdf->MultiCell(0, 10, 'Дата рождения: ' . $userData['birth_date'], 0, 'L');
        $this->pdf->MultiCell(0, 10, 'Адрес: ' . $userData['address'], 0, 'L');
        $this->pdf->MultiCell(0, 10, 'Телефон: ' . $userData['phone'], 0, 'L');
        
        // Дата и подпись
        $this->pdf->Ln(20);
        $this->pdf->Cell(0, 10, 'Дата: ' . date('d.m.Y'), 0, 1, 'L');
        $this->pdf->Cell(0, 10, 'Подпись: _________________', 0, 1, 'L');
        
        return $this->pdf;
    }
    
    // Генерация заявления на водительские права
    public function generateDriverLicenseApplication($userData) {
        $this->pdf->SetTitle('Заявление на получение водительского удостоверения');
        
        // Заголовок
        $this->pdf->SetFont('Arial', 'B', 16);
        $this->pdf->Cell(0, 10, 'ЗАЯВЛЕНИЕ', 0, 1, 'C');
        $this->pdf->SetFont('Arial', '', 12);
        $this->pdf->Cell(0, 10, 'на получение водительского удостоверения', 0, 1, 'C');
        $this->pdf->Ln(10);
        
        // Основной текст
        $this->pdf->MultiCell(0, 10, 'Я, ' . $userData['full_name'] . ', прошу выдать мне водительское удостоверение.', 0, 'L');
        $this->pdf->Ln(5);
        
        // Личные данные
        $this->pdf->MultiCell(0, 10, 'ИИН: ' . $userData['iin'], 0, 'L');
        $this->pdf->MultiCell(0, 10, 'Дата рождения: ' . $userData['birth_date'], 0, 'L');
        $this->pdf->MultiCell(0, 10, 'Адрес: ' . $userData['address'], 0, 'L');
        $this->pdf->MultiCell(0, 10, 'Телефон: ' . $userData['phone'], 0, 'L');
        
        // Категории прав
        $this->pdf->Ln(10);
        $this->pdf->MultiCell(0, 10, 'Запрашиваемые категории: _________________', 0, 'L');
        
        // Дата и подпись
        $this->pdf->Ln(20);
        $this->pdf->Cell(0, 10, 'Дата: ' . date('d.m.Y'), 0, 1, 'L');
        $this->pdf->Cell(0, 10, 'Подпись: _________________', 0, 1, 'L');
        
        return $this->pdf;
    }
    
    // Генерация справки о составе семьи
    public function generateFamilyCompositionApplication($userData) {
        $this->pdf->SetTitle('Заявление на получение справки о составе семьи');
        
        // Заголовок
        $this->pdf->SetFont('Arial', 'B', 16);
        $this->pdf->Cell(0, 10, 'ЗАЯВЛЕНИЕ', 0, 1, 'C');
        $this->pdf->SetFont('Arial', '', 12);
        $this->pdf->Cell(0, 10, 'на получение справки о составе семьи', 0, 1, 'C');
        $this->pdf->Ln(10);
        
        // Основной текст
        $this->pdf->MultiCell(0, 10, 'Я, ' . $userData['full_name'] . ', прошу выдать мне справку о составе семьи.', 0, 'L');
        $this->pdf->Ln(5);
        
        // Личные данные
        $this->pdf->MultiCell(0, 10, 'ИИН: ' . $userData['iin'], 0, 'L');
        $this->pdf->MultiCell(0, 10, 'Адрес: ' . $userData['address'], 0, 'L');
        $this->pdf->MultiCell(0, 10, 'Телефон: ' . $userData['phone'], 0, 'L');
        
        // Дата и подпись
        $this->pdf->Ln(20);
        $this->pdf->Cell(0, 10, 'Дата: ' . date('d.m.Y'), 0, 1, 'L');
        $this->pdf->Cell(0, 10, 'Подпись: _________________', 0, 1, 'L');
        
        return $this->pdf;
    }
    
    // Сохранение PDF в файл
    public function saveDocument($filename) {
        return $this->pdf->Output('F', $filename);
    }
    
    // Отправка PDF в браузер
    public function downloadDocument($filename) {
        return $this->pdf->Output('D', $filename);
    }
}

// Пример использования:
if (isset($_GET['type'])) {
    requireLogin();
    
    try {
        // Получаем данные пользователя
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $userData = $stmt->fetch();
        
        $generator = new DocumentGenerator();
        
        switch ($_GET['type']) {
            case 'udastak':
                $pdf = $generator->generateUdastakApplication($userData);
                $filename = 'udastak_application.pdf';
                break;
            
            case 'driver_license':
                $pdf = $generator->generateDriverLicenseApplication($userData);
                $filename = 'driver_license_application.pdf';
                break;
            
            case 'family_composition':
                $pdf = $generator->generateFamilyCompositionApplication($userData);
                $filename = 'family_composition_application.pdf';
                break;
            
            default:
                die('Неизвестный тип документа');
        }
        
        // Устанавливаем заголовки для PDF
        header('Content-Type: application/pdf');
        header('Content-Disposition: ' . (isset($_GET['download']) ? 'attachment' : 'inline') . '; filename="' . $filename . '"');
        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');
        
        if (isset($_GET['download'])) {
            $generator->downloadDocument($filename);
        } else {
            $upload_dir = 'uploads/' . $_SESSION['user_id'] . '/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            $generator->saveDocument($upload_dir . $filename);
            
            // Сохраняем информацию о документе в базу данных
            $stmt = $conn->prepare("INSERT INTO documents (user_id, file_name, original_name, file_type, file_size, file_path, status) VALUES (?, ?, ?, ?, ?, ?, 'Создан')");
            $stmt->execute([
                $_SESSION['user_id'],
                $filename,
                $filename,
                'application/pdf',
                filesize($upload_dir . $filename),
                $upload_dir . $filename
            ]);
            
            header('Location: applications.php?success=1');
        }
    } catch (Exception $e) {
        die('Ошибка при генерации документа: ' . $e->getMessage());
    }
}
?> 