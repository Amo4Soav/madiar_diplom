<?php
require_once 'config.php';

// Проверяем, не запущена ли уже сессия
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Проверка наличия ID документа
if (!isset($_GET['id'])) {
    die('ID документа не указан');
}

try {
    // Получаем информацию о документе
    $stmt = $conn->prepare("
        SELECT filename, document_type, file_path 
        FROM documents 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$_GET['id'], $_SESSION['user_id']]);
    $document = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$document) {
        die('Документ не найден или у вас нет прав для его скачивания');
    }

    // Используем сохраненный путь к файлу
    $filepath = $document['file_path'];

    // Проверяем существование файла
    if (!file_exists($filepath)) {
        die('Файл не найден на сервере');
    }

    // Определяем MIME-тип файла
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $filepath);
    finfo_close($finfo);

    // Отправляем заголовки для скачивания
    header('Content-Type: ' . $mime_type);
    header('Content-Disposition: attachment; filename="' . basename($document['filename']) . '"');
    header('Content-Length: ' . filesize($filepath));
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Отправляем файл
    readfile($filepath);
    exit();

} catch (Exception $e) {
    die('Ошибка при скачивании файла: ' . $e->getMessage());
}
?> 