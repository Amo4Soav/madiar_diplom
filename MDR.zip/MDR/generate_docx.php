<?php
require_once 'config.php';

// Проверяем, не запущена ли уже сессия
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Функция для транслитерации русского текста
function translit($str) {
    $rus = ['А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я', 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я', ' '];
    $lat = ['A', 'B', 'V', 'G', 'D', 'E', 'E', 'Zh', 'Z', 'I', 'Y', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'F', 'H', 'C', 'Ch', 'Sh', 'Sch', '', 'Y', '', 'E', 'Yu', 'Ya', 'a', 'b', 'v', 'g', 'd', 'e', 'e', 'zh', 'z', 'i', 'y', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'h', 'c', 'ch', 'sh', 'sch', '', 'y', '', 'e', 'yu', 'ya', '_'];
    return str_replace($rus, $lat, $str);
}

// Функция для генерации случайного токена
function generateToken($length = 4) {
    return strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, $length));
}

// Функция для получения типа документа на русском
function getDocumentTypeRus($type) {
    $types = [
        'will' => 'Завещание',
        'document_certification' => 'Удостоверение времени предъявления документов',
        'family_composition' => 'Справка'
    ];
    return $types[$type] ?? $type;
}

// Функция для генерации документа
function generateDocument($type, $userData, $additionalData = []) {
    // Начало RTF документа
    $rtf = "{\rtf1\ansi\deff0
{\fonttbl{\f0\froman Times New Roman;}}
{\colortbl;\red0\green0\blue0;}
\viewkind4\uc1\pard\qc\b\fs32 ЗАЯВЛЕНИЕ\par
\fs28 ";

    switch ($type) {
        case 'will':
            $rtf .= "на оформление завещания\par\par\b0\fs24\ql
Я, {$userData['full_name']}, проживающий(ая) по адресу: {$userData['address']}, настоящим завещаю:\par
\par";

            if (!empty($additionalData['inheritors'])) {
                $rtf .= "Наследники: {$additionalData['inheritors']}\par";
            }

            if (!empty($additionalData['property'])) {
                $rtf .= "Имущество: {$additionalData['property']}\par";
            }

            if (!empty($additionalData['executor'])) {
                $rtf .= "Исполнитель завещания: {$additionalData['executor']}\par";
            }

            $rtf .= "\par
Дата: " . date('d.m.Y') . "\par
Подпись: _________________\par}";
            break;

        case 'document_certification':
            $rtf .= "на удостоверение времени предъявления документов\par\par\b0\fs24\ql
Я, {$userData['full_name']}, прошу удостоверить время предъявления документов.\par
\par
ИИН: {$userData['iin']}\par
Адрес: {$userData['address']}\par
Телефон: {$userData['phone']}\par";

            if (!empty($additionalData['documents'])) {
                $rtf .= "Документы: {$additionalData['documents']}\par";
            }

            if (!empty($additionalData['purpose'])) {
                $rtf .= "Цель удостоверения: {$additionalData['purpose']}\par";
            }

            $rtf .= "\par
Дата: " . date('d.m.Y') . "\par
Подпись: _________________\par}";
            break;

        case 'family_composition':
            $rtf .= "на получение справки о составе семьи\par\par\b0\fs24\ql
Я, {$userData['full_name']}, прошу выдать мне справку о составе семьи.\par
\par
ИИН: {$userData['iin']}\par
Адрес: {$userData['address']}\par
Телефон: {$userData['phone']}\par";

            if (!empty($additionalData['family_members'])) {
                $rtf .= "Состав семьи: {$additionalData['family_members']}\par";
            }

            if (!empty($additionalData['purpose'])) {
                $rtf .= "Цель получения справки: {$additionalData['purpose']}\par";
            }
            break;

        default:
            throw new Exception('Неизвестный тип документа');
    }

    // Создаем временный файл
    $tempFile = tempnam(sys_get_temp_dir(), 'rtf');
    file_put_contents($tempFile, $rtf);

    return $tempFile;
}

// Обработка запроса
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['type'])) {
    try {
        // Получаем данные пользователя из базы
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$userData) {
            throw new Exception('Пользователь не найден');
        }

        $type = $_POST['type'];
        $token = generateToken();
        $translitName = translit($userData['full_name']);
        $docTypeRus = getDocumentTypeRus($type);
        
        // Формируем имя файла: ТипДокумента_ИмяПользователя_Дата_Токен.rtf
        $filename = sprintf(
            '%s_%s_%s_%s.rtf',
            translit($docTypeRus),
            $translitName,
            date('Y-m-d'),
            $token
        );

        // Генерируем документ
        $tempFile = generateDocument($type, $userData, $_POST);

        // Создаем директорию для загрузок, если её нет
        $uploadDir = 'uploads/' . $_SESSION['user_id'];
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Перемещаем файл в директорию пользователя
        $targetPath = $uploadDir . '/' . $filename;
        rename($tempFile, $targetPath);

        // Получаем размер файла
        $fileSize = filesize($targetPath);

        // Сохраняем информацию о документе в базу данных
        $stmt = $conn->prepare("
            INSERT INTO documents (
                user_id,
                file_name,
                original_name,
                file_type,
                file_size,
                file_path,
                status,
                document_type,
                message
            ) VALUES (
                :user_id,
                :file_name,
                :original_name,
                :file_type,
                :file_size,
                :file_path,
                :status,
                :document_type,
                :message
            )
        ");
        
        $stmt->execute([
            ':user_id' => $_SESSION['user_id'],
            ':file_name' => $filename,
            ':original_name' => $filename,
            ':file_type' => 'application/rtf',
            ':file_size' => $fileSize,
            ':file_path' => $targetPath,
            ':status' => 'В обработке',
            ':document_type' => $type,
            ':message' => 'Документ создан и ожидает обработки'
        ]);

        // Получаем ID созданного документа
        $documentId = $conn->lastInsertId();

        // Логируем успешное создание документа
        error_log("Документ успешно создан. ID: $documentId");

        // Перенаправляем на страницу с документами
        $_SESSION['success'] = 'Документ успешно создан';
        header('Location: documents_new.php');
        exit();

    } catch (Exception $e) {
        // Логируем ошибку
        error_log("Ошибка при создании документа: " . $e->getMessage());
        $_SESSION['error'] = 'Ошибка при создании документа: ' . $e->getMessage();
        header('Location: documents_new.php');
        exit();
    }
}

// Если это GET запрос, показываем форму
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создание документа</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">Создание нового документа</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="generate_docx.php">
                            <div class="mb-3">
                                <label class="form-label">Тип документа</label>
                                <select name="type" class="form-select" required>
                                    <option value="">Выберите тип документа</option>
                                    <option value="will">Завещание</option>
                                    <option value="document_certification">Удостоверение времени предъявления документов</option>
                                    <option value="family_composition">Справка о составе семьи</option>
                                </select>
                            </div>

                            <div id="additionalFields" class="mb-3">
                                <!-- Дополнительные поля будут добавлены через JavaScript -->
                            </div>

                            <div class="d-flex justify-content-between">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-file me-2"></i>Создать документ
                                </button>
                                <a href="documents_new.php" class="btn btn-secondary">
                                    <i class="fas fa-times me-2"></i>Отмена
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelector('select[name="type"]').addEventListener('change', function() {
            const additionalFields = document.getElementById('additionalFields');
            additionalFields.innerHTML = '';

            switch (this.value) {
                case 'will':
                    additionalFields.innerHTML = `
                        <div class="mb-3">
                            <label class="form-label">Наследники</label>
                            <textarea name="inheritors" class="form-control" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Имущество</label>
                            <textarea name="property" class="form-control" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Исполнитель завещания</label>
                            <input type="text" name="executor" class="form-control" required>
                        </div>
                    `;
                    break;

                case 'document_certification':
                    additionalFields.innerHTML = `
                        <div class="mb-3">
                            <label class="form-label">Документы</label>
                            <textarea name="documents" class="form-control" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Цель удостоверения</label>
                            <input type="text" name="purpose" class="form-control" required>
                        </div>
                    `;
                    break;

                case 'family_composition':
                    additionalFields.innerHTML = `
                        <div class="mb-3">
                            <label class="form-label">Состав семьи</label>
                            <textarea name="family_members" class="form-control" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Цель получения справки</label>
                            <input type="text" name="purpose" class="form-control" required>
                        </div>
                    `;
                    break;
            }
        });
    </script>
</body>
</html>