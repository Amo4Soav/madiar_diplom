<?php
require_once 'config.php';
requireLogin();

try {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    // Получаем количество документов пользователя
    $stmt = $conn->prepare("SELECT COUNT(*) as doc_count FROM documents WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $doc_count = $stmt->fetch()['doc_count'];

    // Получаем последние документы пользователя
    $stmt = $conn->prepare("SELECT * FROM documents WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
    $stmt->execute([$_SESSION['user_id']]);
    $recent_docs = $stmt->fetchAll();
} catch(PDOException $e) {
    echo "Ошибка: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .profile-section {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .profile-header {
            background: linear-gradient(135deg, #2980b9, #2c3e50);
            color: white;
            padding: 40px 0;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            margin-bottom: 20px;
        }
        .recent-docs {
            margin-top: 30px;
        }
        .doc-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        .doc-item:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Навигационная панель -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-file-alt"></i> Документ-Сервис
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="process.php"><i class="fas fa-file-signature"></i> Обработка документов</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="history.php"><i class="fas fa-history"></i> История</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Шапка профиля -->
    <div class="profile-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-2 text-center">
                    <i class="fas fa-user-circle fa-5x mb-3"></i>
                </div>
                <div class="col-md-10">
                    <h2><?php echo htmlspecialchars($user['full_name']); ?></h2>
                    <p class="mb-0"><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($user['email']); ?></p>
                    <p class="mb-0"><i class="fas fa-phone"></i> <?php echo htmlspecialchars($user['phone'] ?? 'Не указан'); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <!-- Основная информация -->
            <div class="col-md-8">
                <div class="profile-section">
                    <h4 class="mb-4">Личная информация</h4>
                    <div class="row mb-3">
                        <div class="col-md-4 text-muted">ИИН:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($user['iin'] ?? 'Не указан'); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 text-muted">Адрес:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($user['address'] ?? 'Не указан'); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 text-muted">Дата рождения:</div>
                        <div class="col-md-8"><?php echo $user['birth_date'] ? date('d.m.Y', strtotime($user['birth_date'])) : 'Не указана'; ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 text-muted">Дата регистрации:</div>
                        <div class="col-md-8"><?php echo date('d.m.Y', strtotime($user['created_at'])); ?></div>
                    </div>
                </div>

                <!-- Последние документы -->
                <div class="profile-section">
                    <h4 class="mb-4">Последние документы</h4>
                    <?php if (count($recent_docs) > 0): ?>
                        <?php foreach ($recent_docs as $doc): ?>
                            <div class="doc-item">
                                <div class="row align-items-center">
                                    <div class="col-md-1">
                                        <i class="fas fa-file-alt text-primary"></i>
                                    </div>
                                    <div class="col-md-7">
                                        <h6 class="mb-0"><?php echo htmlspecialchars($doc['original_name']); ?></h6>
                                        <small class="text-muted"><?php echo date('d.m.Y H:i', strtotime($doc['created_at'])); ?></small>
                                    </div>
                                    <div class="col-md-2">
                                        <span class="badge <?php echo $doc['status'] === 'Обработан' ? 'bg-success' : 'bg-warning'; ?>">
                                            <?php echo $doc['status']; ?>
                                        </span>
                                    </div>
                                    <div class="col-md-2 text-end">
                                        <a href="#" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-download"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-muted">Нет документов</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Статистика и действия -->
            <div class="col-md-4">
                <div class="profile-section">
                    <h4 class="mb-4">Статистика</h4>
                    <div class="stat-card">
                        <i class="fas fa-file-alt fa-2x mb-2 text-primary"></i>
                        <h3><?php echo $doc_count; ?></h3>
                        <p class="mb-0">Всего документов</p>
                    </div>
                </div>

                <div class="profile-section">
                    <h4 class="mb-4">Действия</h4>
                    <div class="d-grid gap-2">
                        <a href="process.php" class="btn btn-primary">
                            <i class="fas fa-upload"></i> Загрузить документ
                        </a>
                        <a href="edit_profile.php" class="btn btn-outline-primary">
                            <i class="fas fa-edit"></i> Редактировать профиль
                        </a>
                        <a href="logout.php" class="btn btn-danger">
                            <i class="fas fa-sign-out-alt"></i> Выйти
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 