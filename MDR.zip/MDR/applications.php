<?php
require_once 'config.php';
requireLogin();

// Обработка загрузки документа
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['document'])) {
    $file = $_FILES['document'];
    $service_type = $_POST['service_type']; // Тип услуги (например, "will")

    // Создаем директорию для загрузок, если её нет
    $upload_dir = 'uploads/' . $_SESSION['user_id'] . '/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Генерируем уникальное имя файла
    $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $file_name = uniqid() . '.' . $file_extension;
    $target_path = $upload_dir . $file_name;

    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        try {
            // Сохраняем информацию о документе в базу данных
            $stmt = $conn->prepare("
                INSERT INTO documents (
                    user_id,
                    file_name,
                    original_name,
                    file_type,
                    file_size,
                    file_path,
                    status,
                    document_type,
                    message
                ) VALUES (
                    :user_id,
                    :file_name,
                    :original_name,
                    :file_type,
                    :file_size,
                    :file_path,
                    :status,
                    :document_type,
                    :message
                )
            ");

            $stmt->execute([
                ':user_id' => $_SESSION['user_id'],
                ':file_name' => $file_name,
                ':original_name' => $file['name'],
                ':file_type' => $file['type'],
                ':file_size' => $file['size'],
                ':file_path' => $target_path,
                ':status' => 'В обработке',
                ':document_type' => $service_type,
                ':message' => 'Документ успешно загружен и ожидает обработки'
            ]);

            $success_message = "Документ успешно загружен!";
        } catch (PDOException $e) {
            $error_message = "Ошибка при сохранении документа: " . $e->getMessage();
        }
    } else {
        $error_message = "Ошибка при загрузке файла";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Подача заявлений</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .service-card {
            border: none;
            border-radius: 15px;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.2);
        }
        .service-icon {
            font-size: 3rem;
            margin-bottom: 20px;
            color: #2980b9;
        }
        .upload-area {
            border: 2px dashed #ddd;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        .upload-area:hover {
            border-color: #2980b9;
            background: #f8f9fa;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Навигационная панель -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-file-alt"></i> Документ-Сервис
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="applications.php">Подача заявлений</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="process.php">Обработка документов</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="history.php">История</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="profile.php">Личный кабинет</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php">Выйти</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <h1 class="text-center mb-5">Подача заявлений</h1>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <div class="row">
            <!-- Удастак -->
            <div class="col-md-4">
                <div class="card service-card">
                    <div class="card-body text-center">
                        <i class="fas fa-file-contract service-icon"></i> <!-- Иконка для завещания -->
                        <h3>Завещание</h3>
                        <p>Оформление завещания</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#willModal">
                            Подать заявление
                        </button>
                    </div>
                </div>
            </div>

            <!-- Удостоверение времени предъявления документов -->
            <div class="col-md-4">
                <div class="card service-card">
                    <div class="card-body text-center">
                        <i class="fas fa-id-card service-icon"></i>
                        <h3>Удостоверение времени предъявления документов</h3>
                        <p>Нотариусу предоставлено право удостоверять факты: нахождения гражданина в живых, нахождения гражданина в определенном месте, время предъявления документов, а также тождественности гражданина с лицом, изображенным на фотографии, и тождественности собственноручной подписи инвалида по зрению с факсимильным воспроизведением его собственноручной подписи, проставленным с помощью средства механического копирования.</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#documentCertificationModal">
                            Подать заявление
                        </button>
                    </div>
                </div>
            </div>

            <!-- Справка о составе семьи -->
            <div class="col-md-4">
                <div class="card service-card">
                    <div class="card-body text-center">
                        <i class="fas fa-users service-icon"></i>
                        <h3>Справка о составе семьи</h3>
                        <p>Получение справки о составе семьи</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#familyCompositionModal">
                            Подать заявление
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Модальное окно для Завещания -->
    <div class="modal fade" id="willModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Подача заявления на оформление завещания</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-4">
                        <h6>Выберите действие:</h6>
                        <div class="d-grid gap-2">
                            <a href="generate_docx.php?type=will&download=1" class="btn btn-primary" target="_blank">
                                <i class="fas fa-download"></i> Скачать шаблон заявления
                            </a>
                            <a href="generate_docx.php?type=will" class="btn btn-success">
                                <i class="fas fa-save"></i> Сохранить в личном кабинете
                            </a>
                        </div>
                    </div>
                    <hr>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="service_type" value="will">
                        <div class="mb-3">
                            <label class="form-label">Загрузите заполненное заявление</label>
                            <div class="upload-area" id="willUpload">
                                <i class="fas fa-cloud-upload-alt fa-3x mb-3"></i>
                                <p>Перетащите файл сюда или нажмите для выбора</p>
                                <input type="file" name="document" class="d-none" accept=".pdf,.jpg,.jpeg,.png,.html,.htm">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Дополнительные документы</label>
                            <input type="file" name="additional_documents[]" class="form-control" multiple>
                        </div>
                        <button type="submit" class="btn btn-primary">Отправить заявление</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Модальное окно для удостоверения времени предъявления документов -->
    <div class="modal fade" id="documentCertificationModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Подача заявления на удостоверение времени предъявления документов</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-4">
                        <h6>Выберите действие:</h6>
                        <div class="d-grid gap-2">
                            <a href="generate_docx.php?type=document_certification&download=1" class="btn btn-primary" target="_blank">
                                <i class="fas fa-download"></i> Скачать шаблон заявления
                            </a>
                            <a href="generate_docx.php?type=document_certification" class="btn btn-success">
                                <i class="fas fa-save"></i> Сохранить в личном кабинете
                            </a>
                        </div>
                    </div>
                    <hr>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="service_type" value="document_certification">
                        <div class="mb-3">
                            <label class="form-label">Загрузите заполненное заявление</label>
                            <div class="upload-area" id="documentCertificationUpload">
                                <i class="fas fa-cloud-upload-alt fa-3x mb-3"></i>
                                <p>Перетащите файл сюда или нажмите для выбора</p>
                                <input type="file" name="document" class="d-none" accept=".pdf,.jpg,.jpeg,.png,.html,.htm">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Дополнительные документы</label>
                            <input type="file" name="additional_documents[]" class="form-control" multiple>
                        </div>
                        <button type="submit" class="btn btn-primary">Отправить заявление</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Модальное окно для справки о составе семьи -->
    <div class="modal fade" id="familyCompositionModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Подача заявления на справку о составе семьи</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-4">
                        <h6>Выберите действие:</h6>
                        <div class="d-grid gap-2">
                            <a href="generate_docx.php?type=family_composition&download=1" class="btn btn-primary" target="_blank">
                                <i class="fas fa-download"></i> Скачать шаблон заявления
                            </a>
                            <a href="generate_docx.php?type=family_composition" class="btn btn-success">
                                <i class="fas fa-save"></i> Сохранить в личном кабинете
                            </a>
                        </div>
                    </div>
                    <hr>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="service_type" value="family_composition">
                        <div class="mb-3">
                            <label class="form-label">Загрузите заполненное заявление</label>
                            <div class="upload-area" id="familyCompositionUpload">
                                <i class="fas fa-cloud-upload-alt fa-3x mb-3"></i>
                                <p>Перетащите файл сюда или нажмите для выбора</p>
                                <input type="file" name="document" class="d-none" accept=".pdf,.jpg,.jpeg,.png,.html,.htm">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Дополнительные документы</label>
                            <input type="file" name="additional_documents[]" class="form-control" multiple>
                        </div>
                        <button type="submit" class="btn btn-primary">Отправить заявление</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Обработка drag-and-drop для всех зон загрузки
        document.querySelectorAll('.upload-area').forEach(area => {
            area.addEventListener('click', () => {
                area.querySelector('input[type="file"]').click();
            });

            area.addEventListener('dragover', (e) => {
                e.preventDefault();
                area.style.borderColor = '#2980b9';
                area.style.background = '#f8f9fa';
            });

            area.addEventListener('dragleave', () => {
                area.style.borderColor = '#ddd';
                area.style.background = 'white';
            });

            area.addEventListener('drop', (e) => {
                e.preventDefault();
                area.style.borderColor = '#ddd';
                area.style.background = 'white';
                const file = e.dataTransfer.files[0];
                area.querySelector('input[type="file"]').files = e.dataTransfer.files;
            });
        });
    </script>
</body>
</html>