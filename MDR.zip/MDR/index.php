<?php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Портал обработки документов</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .navbar-brand {
            font-weight: bold;
            color: #2c3e50;
        }
        .hero-section {
            background: linear-gradient(135deg, #2980b9, #2c3e50);
            color: white;
            padding: 60px 0;
        }
        .feature-card {
            border: none;
            border-radius: 10px;
            transition: transform 0.3s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .feature-card:hover {
            transform: translateY(-5px);
        }
        .footer {
            background-color: #2c3e50;
            color: white;
            padding: 40px 0;
        }
        .service-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .service-card:hover {
            background: #e9ecef;
            transform: translateY(-3px);
        }
        .search-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <!-- Навигационная панель -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-file-alt"></i> Документ-Сервис
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="applications.php">Подача заявлений</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="process.php">Обработка документов</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="history.php">История</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <?php if (isLoggedIn()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="profile.php">Личный кабинет</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php">Выйти</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="btn btn-primary" href="register.php">
                                <i class="fas fa-user-plus"></i> Личный кабинет
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Главный раздел -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="display-4 mb-4">Электронная обработка документов</h1>
                    <p class="lead mb-4">Автоматизируйте работу с документами быстро и эффективно</p>
                </div>
                <div class="col-md-4">
                    <div class="search-box">
                        <h5 class="mb-3">Поиск услуг</h5>
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Введите название услуги...">
                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Секция популярных услуг -->
    <section class="services py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-4">Популярные услуги</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-file-alt fa-3x text-primary mb-3"></i>
                            <h5 class="card-title">Подача заявлений</h5>
                            <p class="card-text">Подача заявлений на получение документов и справок онлайн</p>
                            <a href="applications.php" class="btn btn-primary">Перейти к услуге</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <i class="fas fa-sync fa-2x mb-3 text-success"></i>
                        <h5>Обработка документов</h5>
                        <p>Автоматическая проверка документов</p>
                        <a href="documents_new.php" class="btn btn-outline-success btn-sm">Обработать документы</a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <i class="fas fa-archive fa-2x mb-3 text-info"></i>
                        <h5>Архивация</h5>
                        <p>Безопасное хранение и управление документами</p>
                        <a href="archive_documents.php" class="btn btn-outline-info btn-sm">Архивировать</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Процесс работы -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Как это работает</h2>
            <div class="row">
                <div class="col-md-3">
                    <div class="text-center">
                        <i class="fas fa-upload fa-3x mb-3 text-primary"></i>
                        <h5>Загрузка</h5>
                        <p>Загрузите ваши документы в систему</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="text-center">
                        <i class="fas fa-robot fa-3x mb-3 text-success"></i>
                        <h5>Обработка</h5>
                        <p>Автоматическая обработка данных</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="text-center">
                        <i class="fas fa-check-circle fa-3x mb-3 text-info"></i>
                        <h5>Проверка</h5>
                        <p>Верификация и валидация</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="text-center">
                        <i class="fas fa-file-download fa-3x mb-3 text-warning"></i>
                        <h5>Результат</h5>
                        <p>Получение готовых документов</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Футер -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>О сервисе</h5>
                    <p>Автоматизированная система обработки и управления документами</p>
                </div>
                <div class="col-md-4">
                    <h5>Контакты</h5>
                    <p>Email: support@docs-service.kz<br>Телефон: +7 (7XX) XXX-XX-XX</p>
                </div>
                <div class="col-md-4">
                    <h5>Техподдержка</h5>
                    <p>Круглосуточная поддержка пользователей</p>
                    <button class="btn btn-light btn-sm">Связаться с поддержкой</button>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
