<?php
session_start();

// Параметры подключения к базе данных
$db_host = 'localhost';
$db_name = 'document_service';
$db_user = 'root';
$db_pass = '';

function isAdmin($user_id) {
    global $conn;

    try {
        // Получаем роль пользователя из базы данных
        $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        // Проверяем, является ли пользователь администратором
        return ($user && $user['role'] === 'admin');
    } catch (PDOException $e) {
        error_log("Ошибка при проверке роли пользователя: " . $e->getMessage());
        return false;
    }
}   

try {
    $conn = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Функция для проверки авторизации
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Функция для перенаправления неавторизованных пользователей
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}
?> 