<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'config.php';
require_once 'classes/Notification.php';
requireLogin();

// Создаем экземпляр класса уведомлений
$notification = new Notification($conn);

// Функция для безопасного получения документа
function getDocument($doc_id) {
    global $conn;
    try {
        $stmt = $conn->prepare("SELECT * FROM documents WHERE id = ?");
        $stmt->execute([$doc_id]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Ошибка при получении документа: " . $e->getMessage());
        return false;
    }
}

// Функция для обновления статуса документа
function updateDocumentStatus($doc_id, $status, $comment) {
    global $conn, $notification;
    try {
        $conn->beginTransaction();

        // Получаем информацию о документе и пользователе
        $stmt = $conn->prepare("
            SELECT d.*, u.email, u.full_name 
            FROM documents d 
            JOIN users u ON d.user_id = u.id 
            WHERE d.id = ?
        ");
        $stmt->execute([$doc_id]);
        $doc_info = $stmt->fetch();

        // Обновляем статус документа
        $stmt = $conn->prepare("UPDATE documents SET status = ?, message = ?, updated_at = NOW() WHERE id = ?");
        $result = $stmt->execute([$status, $comment, $doc_id]);
        
        if ($result) {
            // Добавляем запись в историю обработки
            $stmt = $conn->prepare("INSERT INTO processing_history (document_id, status, message) VALUES (?, ?, ?)");
            $stmt->execute([$doc_id, $status, $comment]);

            // Создаем уведомление
            $message = "Ваш документ \"{$doc_info['original_name']}\" был " . 
                      ($status === 'Одобрен' ? 'одобрен' : 'отклонен') . 
                      ($comment ? ". Комментарий: $comment" : "");

            $notification->create($doc_info['user_id'], $doc_id, $message, $status);

            // Отправляем email
            $subject = "Статус вашего документа изменен";
            $notification->sendEmail(
                $doc_info['email'],
                $subject,
                $message
            );
        }
        
        $conn->commit();
        return true;
    } catch (PDOException $e) {
        $conn->rollBack();
        error_log("Ошибка при обновлении статуса документа: " . $e->getMessage());
        return false;
    }
}

// Обработка POST запроса
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isAdmin($_SESSION['user_id'])) {
    $doc_id = filter_input(INPUT_POST, 'document_id', FILTER_VALIDATE_INT);
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
    $comment = filter_input(INPUT_POST, 'comment', FILTER_SANITIZE_STRING);
    
    if (!$doc_id || !$action) {
        $_SESSION['error'] = 'Неверные параметры запроса';
    } else {
        $document = getDocument($doc_id);
        if ($document) {
            $status = ($action === 'approve') ? 'Одобрен' : 'Отклонен';
            if (updateDocumentStatus($doc_id, $status, $comment)) {
                $_SESSION['success'] = 'Документ успешно обработан';
            } else {
                $_SESSION['error'] = 'Ошибка при обработке документа';
            }
        } else {
            $_SESSION['error'] = 'Документ не найден';
        }
    }
    
    header('Location: process.php');
    exit;
}

// Получение списка документов для проверки
try {
    $stmt = $conn->prepare("
        SELECT 
            d.*, 
            u.full_name as user_name,
            n.name as notary_name
        FROM documents d 
        JOIN users u ON d.user_id = u.id
        LEFT JOIN notaries n ON d.notary_id = n.id
        WHERE d.status = 'В обработке' 
        ORDER BY d.created_at DESC
    ");
    $stmt->execute();
    $documents = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Ошибка при получении списка документов: " . $e->getMessage());
    $documents = [];
    $_SESSION['error'] = 'Ошибка при загрузке списка документов';
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Обработка документов</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center mb-5">Обработка документов</h1>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php 
                echo htmlspecialchars($_SESSION['success']); 
                unset($_SESSION['success']);
                ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php 
                echo htmlspecialchars($_SESSION['error']); 
                unset($_SESSION['error']);
                ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isAdmin($_SESSION['user_id'])): ?>
            <?php if (!empty($documents)): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Пользователь</th>
                                <th>Документ</th>
                                <th>Тип</th>
                                <th>Размер</th>
                                <th>Дата загрузки</th>
                                <th>Нотариус</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($documents as $doc): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($doc['user_name']); ?></td>
                                    <td>
                                        <a href="view_document.php?id=<?php echo $doc['id']; ?>" target="_blank" class="text-decoration-none">
                                            <i class="fas fa-file-alt me-2"></i>
                                            <?php echo htmlspecialchars($doc['original_name']); ?>
                                        </a>
                                    </td>
                                    <td><?php echo htmlspecialchars($doc['file_type']); ?></td>
                                    <td><?php echo number_format($doc['file_size'] / 1024, 2) . ' KB'; ?></td>
                                    <td><?php echo date('d.m.Y H:i', strtotime($doc['created_at'])); ?></td>
                                    <td>
                                        <?php if (!empty($doc['notary_name'])): ?>
                                            <?php echo htmlspecialchars($doc['notary_name']); ?>
                                        <?php else: ?>
                                            <span class="text-muted">Не назначен</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#approveModal<?php echo $doc['id']; ?>">
                                                <i class="fas fa-check me-1"></i> Одобрить
                                            </button>
                                            <button class="btn btn-danger btn-sm ms-1" data-bs-toggle="modal" data-bs-target="#rejectModal<?php echo $doc['id']; ?>">
                                                <i class="fas fa-times me-1"></i> Отклонить
                                            </button>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Модальное окно для одобрения -->
                                <div class="modal fade" id="approveModal<?php echo $doc['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Одобрение документа</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <form method="POST" class="needs-validation" novalidate>
                                                <div class="modal-body">
                                                    <input type="hidden" name="document_id" value="<?php echo $doc['id']; ?>">
                                                    <input type="hidden" name="action" value="approve">
                                                    <div class="mb-3">
                                                        <label class="form-label">Комментарий к одобрению</label>
                                                        <textarea name="comment" class="form-control" rows="3"></textarea>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                                                    <button type="submit" class="btn btn-success">
                                                        <i class="fas fa-check me-1"></i> Подтвердить одобрение
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Модальное окно для отклонения -->
                                <div class="modal fade" id="rejectModal<?php echo $doc['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Отклонение документа</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <form method="POST" class="needs-validation" novalidate>
                                                <div class="modal-body">
                                                    <input type="hidden" name="document_id" value="<?php echo $doc['id']; ?>">
                                                    <input type="hidden" name="action" value="reject">
                                                    <div class="mb-3">
                                                        <label class="form-label">Причина отклонения</label>
                                                        <textarea name="comment" class="form-control" rows="3" required></textarea>
                                                        <div class="invalid-feedback">
                                                            Пожалуйста, укажите причину отклонения
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="fas fa-times me-1"></i> Подтвердить отклонение
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    На данный момент нет документов для проверки
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                У вас нет прав доступа к этой странице. Пожалуйста, войдите как администратор.
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Валидация форм
    document.addEventListener('DOMContentLoaded', function() {
        var forms = document.querySelectorAll('.needs-validation');
        Array.prototype.slice.call(forms).forEach(function(form) {
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    });
    </script>
</body>
</html>