<?php
require_once 'config.php';
require_once 'classes/Notification.php';
requireLogin();

$notification = new Notification($conn);
$notifications = $notification->getUserNotifications($_SESSION['user_id']);

// Отмечаем уведомление как прочитанное
if (isset($_POST['mark_read']) && isset($_POST['notification_id'])) {
    $notification->markAsRead($_POST['notification_id'], $_SESSION['user_id']);
    header('Location: notifications.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Уведомления</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .notification-card {
            transition: all 0.3s ease;
        }
        .notification-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .unread {
            background-color: #f8f9fa;
            border-left: 4px solid #0d6efd;
        }
    </style>
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center mb-5">
            <i class="fas fa-bell me-2"></i>
            Уведомления
        </h1>

        <?php if (!empty($notifications)): ?>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <?php foreach ($notifications as $notif): ?>
                        <div class="card mb-3 notification-card <?php echo !$notif['is_read'] ? 'unread' : ''; ?>">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h5 class="card-title mb-0">
                                        <i class="fas <?php echo $notif['status'] === 'Одобрен' ? 'fa-check-circle text-success' : 'fa-times-circle text-danger'; ?> me-2"></i>
                                        <?php echo htmlspecialchars($notif['document_name']); ?>
                                    </h5>
                                    <small class="text-muted">
                                        <?php echo date('d.m.Y H:i', strtotime($notif['created_at'])); ?>
                                    </small>
                                </div>
                                <p class="card-text"><?php echo htmlspecialchars($notif['message']); ?></p>
                                <?php if (!$notif['is_read']): ?>
                                    <form method="POST" class="mt-2">
                                        <input type="hidden" name="notification_id" value="<?php echo $notif['id']; ?>">
                                        <button type="submit" name="mark_read" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-check me-1"></i> Отметить как прочитанное
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info text-center">
                <i class="fas fa-info-circle me-2"></i>
                У вас нет новых уведомлений
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 