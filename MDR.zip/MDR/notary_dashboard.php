<?php
require_once 'config.php';

// Проверяем, не запущена ли уже сессия
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Проверка авторизации нотариуса
if (!isset($_SESSION['user_id']) || !isAdmin($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Получаем ID нотариуса
$notaryId = $_SESSION['user_id'];

// Обработка POST-запроса (нотариус берет документ в работу)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['document_id'])) {
    $documentId = $_POST['document_id'];

    try {
        // Обновляем статус документа и назначаем нотариуса
        $stmt = $conn->prepare("
            UPDATE documents 
            SET status = 'В обработке', notary_id = ?
            WHERE id = ? AND status = 'Ожидает нотариуса'
        ");
        $stmt->execute([$notaryId, $documentId]);

        if ($stmt->rowCount() > 0) {
            $_SESSION['success'] = 'Документ успешно взят в работу';
        } else {
            $_SESSION['error'] = 'Документ уже взят другим нотариусом';
        }

        header('Location: notary_dashboard.php');
        exit();
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Ошибка при взятии документа: ' . $e->getMessage();
        header('Location: notary_dashboard.php');
        exit();
    }
}

// Получаем список документов, ожидающих нотариуса
try {
    $stmt = $conn->prepare("
        SELECT d.*, u.full_name as user_name 
        FROM documents d
        JOIN users u ON d.user_id = u.id
        WHERE d.status = 'Ожидает нотариуса'
        ORDER BY d.created_at DESC
    ");
    $stmt->execute();
    $documents = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error_message = 'Ошибка при получении документов: ' . $e->getMessage();
    $documents = [];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель нотариуса</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center mb-5">Панель нотариуса</h1>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_SESSION['success']); ?>
                <?php unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($_SESSION['error']); ?>
                <?php unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (empty($documents)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                Нет документов, ожидающих обработки.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Документ</th>
                            <th>Пользователь</th>
                            <th>Дата создания</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($documents as $document): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($document['id']); ?></td>
                                <td><?php echo htmlspecialchars($document['filename']); ?></td>
                                <td><?php echo htmlspecialchars($document['user_name']); ?></td>
                                <td><?php echo date('d.m.Y H:i', strtotime($document['created_at'])); ?></td>
                                <td>
                                    <form method="POST" action="notary_dashboard.php">
                                        <input type="hidden" name="document_id" value="<?php echo $document['id']; ?>">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fas fa-check me-1"></i> Взять в работу
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>