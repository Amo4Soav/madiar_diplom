<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'config.php';

// Проверяем, не запущена ли уже сессия
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Получение одобренных документов
try {
    $stmt = $conn->prepare("
        SELECT 
            d.id,
            COALESCE(d.filename, 'Файл не загружен') as filename,
            COALESCE(d.document_type, 'Не указан') as document_type,
            d.status,
            COALESCE(d.message, 'Нет сообщения') as message,
            d.created_at,
            d.processing_result,
            dc.name as category_name
        FROM documents d
        LEFT JOIN document_category_relations dcr ON d.id = dcr.document_id
        LEFT JOIN document_categories dc ON dcr.category_id = dc.id
        WHERE d.user_id = ? AND d.status = 'Обработан'
        ORDER BY d.created_at DESC
    ");
    
    $stmt->execute([$_SESSION['user_id']]);
    $documents = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    error_log("Ошибка БД: " . $e->getMessage());
    $error_message = "Произошла ошибка при получении документов";
    $documents = [];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Архив документов</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .document-card {
            transition: all 0.3s ease;
            border: 1px solid #dee2e6;
        }
        .document-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .status-badge {
            font-size: 0.9em;
            padding: 0.5em 1em;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <div class="row mb-4">
            <div class="col">
                <h2><i class="fas fa-archive me-2"></i>Архив документов</h2>
                <p class="text-muted">Здесь находятся все ваши одобренные и обработанные документы</p>
            </div>
            <div class="col-auto">
                <a href="documents_new.php" class="btn btn-primary">
                    <i class="fas fa-clock me-2"></i>Документы в обработке
                </a>
            </div>
        </div>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <?php if (empty($documents)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                В архиве пока нет одобренных документов.
            </div>
        <?php else: ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php foreach ($documents as $document): ?>
                    <div class="col">
                        <div class="card document-card h-100">
                            <div class="card-header bg-transparent">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted small">
                                        ID: <?php echo htmlspecialchars($document['id']); ?>
                                    </span>
                                    <span class="badge bg-success">
                                        <i class="fas fa-check me-1"></i>
                                        Одобрен
                                    </span>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title text-truncate">
                                    <i class="fas fa-file-alt me-2"></i>
                                    <?php echo htmlspecialchars($document['filename']); ?>
                                </h5>
                                <p class="card-text">
                                    <strong>Тип документа:</strong><br>
                                    <?php echo htmlspecialchars($document['document_type']); ?>
                                </p>
                                <?php if ($document['category_name']): ?>
                                <p class="card-text">
                                    <strong>Категория:</strong><br>
                                    <?php echo htmlspecialchars($document['category_name']); ?>
                                </p>
                                <?php endif; ?>
                                <p class="card-text">
                                    <strong>Дата создания:</strong><br>
                                    <?php echo date('d.m.Y H:i', strtotime($document['created_at'])); ?>
                                </p>
                                <?php if ($document['processing_result']): ?>
                                    <p class="card-text">
                                        <strong>Результат обработки:</strong><br>
                                        <?php echo htmlspecialchars($document['processing_result']); ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer bg-transparent">
                                <div class="d-flex justify-content-between">
                                    <a href="download_document.php?id=<?php echo urlencode($document['id']); ?>" 
                                       class="btn btn-info btn-sm">
                                        <i class="fas fa-download me-1"></i>
                                        Скачать
                                    </a>
                                    <button type="button" 
                                            class="btn btn-outline-primary btn-sm"
                                            data-bs-toggle="modal" 
                                            data-bs-target="#historyModal<?php echo $document['id']; ?>">
                                        <i class="fas fa-history me-1"></i>
                                        История
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Модальное окно с историей -->
                    <div class="modal fade" id="historyModal<?php echo $document['id']; ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">История обработки документа</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <?php
                                    // Получаем историю обработки документа
                                    $stmt = $conn->prepare("
                                        SELECT status, message, created_at
                                        FROM processing_history
                                        WHERE document_id = ?
                                        ORDER BY created_at DESC
                                    ");
                                    $stmt->execute([$document['id']]);
                                    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    if (!empty($history)): ?>
                                        <div class="timeline">
                                            <?php foreach ($history as $event): ?>
                                                <div class="timeline-item mb-3">
                                                    <div class="d-flex justify-content-between">
                                                        <strong><?php echo htmlspecialchars($event['status']); ?></strong>
                                                        <small class="text-muted">
                                                            <?php echo date('d.m.Y H:i', strtotime($event['created_at'])); ?>
                                                        </small>
                                                    </div>
                                                    <p class="mb-0"><?php echo htmlspecialchars($event['message']); ?></p>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <p class="text-muted">История обработки отсутствует</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 