<?php
require_once 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $email = trim($_POST['email']);
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $iin = trim($_POST['iin']);
    $address = trim($_POST['address']);
    $birth_date = $_POST['birth_date'];

    // Проверка обязательных полей
    if (empty($username) || empty($password) || empty($email) || empty($full_name) || empty($iin)) {
        $error = 'Пожалуйста, заполните все обязательные поля';
    } else {
        try {
            // Проверка существующего пользователя
            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            
            if ($stmt->rowCount() > 0) {
                $error = 'Пользователь с таким именем или email уже существует';
            } else {
                // Хеширование пароля
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Добавление пользователя
                $stmt = $conn->prepare("INSERT INTO users (username, password, email, full_name, phone, iin, address, birth_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$username, $hashed_password, $email, $full_name, $phone, $iin, $address, $birth_date]);
                
                $success = 'Регистрация успешна! Теперь вы можете войти в систему.';
                header("refresh:2;url=login.php");
            }
        } catch(PDOException $e) {
            $error = 'Ошибка при регистрации: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .registration-form {
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .required-field::after {
            content: "*";
            color: red;
            margin-left: 4px;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container">
        <div class="registration-form">
            <h2 class="text-center mb-4">Регистрация</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label class="required-field">Имя пользователя</label>
                    <input type="text" name="username" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="required-field">Пароль</label>
                    <input type="password" name="password" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="required-field">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="required-field">ФИО</label>
                    <input type="text" name="full_name" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="required-field">ИИН</label>
                    <input type="text" name="iin" class="form-control" pattern="[0-9]{12}" title="ИИН должен содержать 12 цифр" required>
                </div>

                <div class="form-group">
                    <label>Телефон</label>
                    <input type="tel" name="phone" class="form-control" pattern="[\+]?[0-9]{11,12}" title="Формат: +7XXXXXXXXXX">
                </div>

                <div class="form-group">
                    <label>Адрес</label>
                    <textarea name="address" class="form-control" rows="2"></textarea>
                </div>

                <div class="form-group">
                    <label>Дата рождения</label>
                    <input type="date" name="birth_date" class="form-control">
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
                </div>

                <div class="text-center mt-3">
                    <p>Уже есть аккаунт? <a href="login.php">Войти</a></p>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 