<?php
// URL архива PHPWord
$url = 'https://github.com/PHPOffice/PHPWord/archive/refs/tags/0.18.3.zip';
$zipFile = 'phpword.zip';
$extractPath = './';

// Скачиваем архив
if (file_put_contents($zipFile, file_get_contents($url))) {
    echo "Архив успешно скачан\n";
    
    // Создаем папку lib если её нет
    if (!file_exists('lib')) {
        mkdir('lib');
    }
    
    // Распаковываем архив
    $zip = new ZipArchive;
    if ($zip->open($zipFile) === TRUE) {
        $zip->extractTo($extractPath);
        $zip->close();
        echo "Архив успешно распакован\n";
        
        // Переименовываем папку
        rename('PHPWord-0.18.3', 'lib/PHPWord');
        
        // Удаляем архив
        unlink($zipFile);
        echo "Установка завершена\n";
    } else {
        echo "Ошибка при распаковке архива\n";
    }
} else {
    echo "Ошибка при скачивании архива\n";
}
?> 