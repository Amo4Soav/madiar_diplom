<?php
require_once 'config.php';

// Проверяем, не запущена ли уже сессия
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Проверка метода запроса
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: documents_new.php');
    exit();
}

// Проверка наличия ID документа
if (!isset($_POST['document_id'])) {
    $_SESSION['error'] = 'ID документа не указан';
    header('Location: documents_new.php');
    exit();
}

if (!function_exists('isAdmin')) {
    function isAdmin($userId, $conn) {
        $stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        return $user && $user['role'] === 'admin';
    }
}

try {
    // Получаем информацию о документе
    $stmt = $conn->prepare("
        SELECT * FROM documents 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$_POST['document_id'], $_SESSION['user_id']]);
    $document = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$document) {
        $_SESSION['error'] = 'Документ не найден или у вас нет прав для его обработки';
        header('Location: documents_new.php');
        exit();
    }

    // Проверяем тип документа и выполняем соответствующую обработку
    $filepath = 'uploads/' . $document['filename'];
    
    if (!file_exists($filepath)) {
        $_SESSION['error'] = 'Файл не найден на сервере';
        header('Location: documents_new.php');
        exit();
    }

    // Определяем тип файла
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $filepath);
    finfo_close($finfo);

    // Автоматическая обработка для HTML-файлов
    if ($mime_type === 'text/html') {
        $content = file_get_contents($filepath);
        
        // Проверяем наличие обязательных полей
        $required_fields = ['ФИО', 'ИИН', 'Адрес', 'Телефон'];
        $is_valid = true;
        
        foreach ($required_fields as $field) {
            if (strpos($content, $field) === false) {
                $is_valid = false;
                break;
            }
        }

        // Обновляем статус документа
        $new_status = $is_valid ? 'approved' : 'rejected';
        $message = $is_valid ? 'Документ прошел автоматическую проверку' : 'Документ не содержит необходимых полей';
    } else {
        // Для не-HTML файлов отправляем на ручную проверку
        $new_status = 'pending';
        $message = 'Документ отправлен на ручную проверку администратору';
    }

    // Проверяем, что статус изменился на 'Обработан'
    if ($new_status === 'Обработан') {
        // Создаем уведомление
        $stmt = $conn->prepare("
            INSERT INTO notifications (user_id, document_id, message, status, is_read)
            VALUES (?, ?, ?, ?, 0)
        ");
        $stmt->execute([
            $document['user_id'],
            $document['id'],
            'Ваш документ был одобрен и обработан',
            'Одобрен'
        ]);
    }

    // Обновляем статус в базе данных
    $stmt = $conn->prepare("
        UPDATE documents 
        SET status = ?, message = ? 
        WHERE id = ?
    ");
    $stmt->execute([$new_status, $message, $_POST['document_id']]);

    // Добавляем уведомление
    $stmt = $conn->prepare("
        INSERT INTO notifications (user_id, message, type) 
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$_SESSION['user_id'], $message, $new_status]);

    $_SESSION['success'] = 'Документ успешно обработан';

} catch (Exception $e) {
    $_SESSION['error'] = 'Ошибка при обработке документа: ' . $e->getMessage();
}

header('Location: documents_new.php');
exit();
?> 