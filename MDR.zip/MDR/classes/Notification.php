<?php
class Notification {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Создание уведомления
    public function create($user_id, $document_id, $message, $status) {
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO notifications (user_id, document_id, message, status)
                VALUES (:user_id, :document_id, :message, :status)
            ");
            
            return $stmt->execute([
                'user_id' => $user_id,
                'document_id' => $document_id,
                'message' => $message,
                'status' => $status
            ]);
        } catch (PDOException $e) {
            error_log("Ошибка создания уведомления: " . $e->getMessage());
            return false;
        }
    }
    
    // Отправка email уведомления
    public function sendEmail($user_email, $subject, $message) {
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: Система обработки документов <noreply@example.com>\r\n";
        
        $emailTemplate = "
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: #f8f9fa; padding: 20px; text-align: center; }
                    .content { padding: 20px; }
                    .footer { text-align: center; padding: 20px; font-size: 12px; color: #6c757d; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='header'>
                        <h2>$subject</h2>
                    </div>
                    <div class='content'>
                        $message
                    </div>
                    <div class='footer'>
                        Это автоматическое уведомление. Пожалуйста, не отвечайте на него.
                    </div>
                </div>
            </body>
            </html>
        ";
        
        return mail($user_email, $subject, $emailTemplate, $headers);
    }
    
    // Получение уведомлений пользователя
    public function getUserNotifications($user_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT n.*, d.original_name as document_name 
                FROM notifications n
                JOIN documents d ON n.document_id = d.id
                WHERE n.user_id = :user_id 
                ORDER BY n.created_at DESC
            ");
            
            $stmt->execute(['user_id' => $user_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Ошибка получения уведомлений: " . $e->getMessage());
            return [];
        }
    }
    
    // Отметить уведомление как прочитанное
    public function markAsRead($notification_id, $user_id) {
        try {
            $stmt = $this->conn->prepare("
                UPDATE notifications 
                SET is_read = TRUE 
                WHERE id = :id AND user_id = :user_id
            ");
            
            return $stmt->execute([
                'id' => $notification_id,
                'user_id' => $user_id
            ]);
        } catch (PDOException $e) {
            error_log("Ошибка обновления статуса уведомления: " . $e->getMessage());
            return false;
        }
    }
} 