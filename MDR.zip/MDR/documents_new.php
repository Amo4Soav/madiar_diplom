<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'config.php';

// Проверяем, не запущена ли уже сессия
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Получение документов с дополнительной проверкой
try {
    $stmt = $conn->prepare("
        SELECT 
            d.id,
            COALESCE(d.filename, 'Файл не загружен') as filename,
            COALESCE(d.document_type, 'Не указан') as document_type,
            d.status,
            COALESCE(d.message, 'Нет сообщения') as message,
            d.created_at,
            d.processing_result,
            n.name as notary_name
        FROM documents d
        LEFT JOIN document_notary_relations dnr ON d.id = dnr.document_id
        LEFT JOIN notaries n ON dnr.notary_id = n.id
        WHERE d.user_id = ? AND d.status = 'В обработке'
        ORDER BY d.created_at DESC
    ");
    
    $stmt->execute([$_SESSION['user_id']]);
    $documents = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Отладочная информация
    error_log("Получено документов в обработке: " . count($documents));
    foreach ($documents as $doc) {
        error_log("Документ ID: " . $doc['id'] . ", Статус: " . $doc['status']);
    }
    
} catch (PDOException $e) {
    error_log("Ошибка БД: " . $e->getMessage());
    $error_message = "Произошла ошибка при получении документов";
    $documents = [];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Документы в обработке</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .document-card {
            transition: all 0.3s ease;
            border: 1px solid #dee2e6;
        }
        .document-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .status-badge {
            font-size: 0.9em;
            padding: 0.5em 1em;
        }
        .processing-status {
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <div class="row mb-4">
            <div class="col">
                <h2>Документы в обработке</h2>
                <p class="text-muted">Здесь отображаются только документы, которые находятся в процессе обработки</p>
            </div>
            <div class="col-auto">
                <a href="generate_docx.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Создать новый документ
                </a>
            </div>
        </div>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <?php if (empty($documents)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                У вас нет документов в обработке. Все документы обработаны.
                <br>
                <a href="all_documents.php" class="alert-link">Посмотреть все документы</a>
            </div>
        <?php else: ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php foreach ($documents as $document): ?>
                    <div class="col">
                        <div class="card document-card h-100">
                            <div class="card-header bg-transparent">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted small">
                                        ID: <?php echo htmlspecialchars($document['id']); ?>
                                    </span>
                                    <span class="badge bg-warning processing-status">
                                        <i class="fas fa-spinner fa-spin me-1"></i>
                                        В обработке
                                    </span>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title text-truncate">
                                    <i class="fas fa-file-alt me-2"></i>
                                    <?php echo htmlspecialchars($document['filename']); ?>
                                </h5>
                                <p class="card-text">
                                    <strong>Тип документа:</strong><br>
                                    <?php echo htmlspecialchars($document['document_type']); ?>
                                </p>
                                <p class="card-text">
                                    <strong>Дата создания:</strong><br>
                                    <?php echo date('d.m.Y H:i', strtotime($document['created_at'])); ?>
                                </p>
                                <?php if (!empty($document['notary_name'])): ?>
                                    <p class="card-text">
                                        <strong>Нотариус:</strong><br>
                                        <?php echo htmlspecialchars($document['notary_name']); ?>
                                    </p>
                                <?php endif; ?>
                                <?php if ($document['message']): ?>
                                    <p class="card-text">
                                        <strong>Статус обработки:</strong><br>
                                        <?php echo htmlspecialchars($document['message']); ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer bg-transparent">
                                <div class="d-flex justify-content-between">
                                    <a href="download_document.php?id=<?php echo urlencode($document['id']); ?>" 
                                       class="btn btn-info btn-sm">
                                        <i class="fas fa-download me-1"></i>
                                        Скачать
                                    </a>
                                    <a href="process.php?id=<?php echo urlencode($document['id']); ?>" 
                                       class="btn btn-primary btn-sm">
                                        <i class="fas fa-sync-alt me-1"></i>
                                        Проверить статус
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="mt-4 text-center">
                <a href="archive_documents.php" class="btn btn-outline-primary">
                    <i class="fas fa-list me-2"></i>Посмотреть все документы
                </a>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>