<?php
require_once 'config.php';

try {
    // Удаляем существующий первичный ключ и изменяем id
    try {
        $conn->exec("ALTER TABLE documents DROP PRIMARY KEY");
        $conn->exec("ALTER TABLE documents MODIFY COLUMN id INT AUTO_INCREMENT PRIMARY KEY");
        echo "Столбец id успешно изменен\n";
    } catch (PDOException $e) {
        echo "Ошибка при изменении столбца id: " . $e->getMessage() . "\n";
    }

    // Определяем столбцы для добавления
    $columns = [
        'user_id' => 'INT NOT NULL',
        'filename' => 'VARCHAR(255) NOT NULL DEFAULT ""',
        'document_type' => 'VARCHAR(50) NOT NULL DEFAULT ""',
        'status' => 'VARCHAR(20) NOT NULL DEFAULT "pending"',
        'message' => 'TEXT',
        'created_at' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'
    ];

    // Добавляем каждый столбец отдельно
    foreach ($columns as $column => $definition) {
        try {
            $conn->exec("ALTER TABLE documents ADD COLUMN $column $definition");
            echo "Столбец $column успешно добавлен\n";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
                echo "Столбец $column уже существует\n";
            } else {
                echo "Ошибка при добавлении столбца $column: " . $e->getMessage() . "\n";
            }
        }
    }

    // Добавляем столбец role в таблицу users
    try {
        $conn->exec("ALTER TABLE users ADD COLUMN role ENUM('user', 'admin') DEFAULT 'user'");
        echo "Столбец role успешно добавлен в таблицу users\n";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
            echo "Столбец role уже существует\n";
        } else {
            throw $e;
        }
    }
    
    // Проверяем существование пользователя admin
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute(['admin']);
    
    if ($stmt->fetch()) {
        // Если admin существует, обновляем его
        $stmt = $conn->prepare("
            UPDATE users 
            SET role = 'admin',
                password = :password,
                email = :email,
                full_name = :full_name
            WHERE username = 'admin'
        ");
        
        $stmt->execute([
            'password' => password_hash('admin123', PASSWORD_DEFAULT),
            'email' => 'admin@example.com',
            'full_name' => 'Администратор'
        ]);
        echo "Администратор успешно обновлен\n";
    } else {
        // Если admin не существует, создаем его
        $stmt = $conn->prepare("
            INSERT INTO users (username, password, email, full_name, role)
            VALUES (:username, :password, :email, :full_name, 'admin')
        ");
        
        $stmt->execute([
            'username' => 'admin',
            'password' => password_hash('admin123', PASSWORD_DEFAULT),
            'email' => 'admin@example.com',
            'full_name' => 'Администратор'
        ]);
        echo "Администратор успешно создан\n";
    }
    
    echo "\nДанные для входа администратора:\n";
    echo "Логин: admin\n";
    echo "Пароль: admin123\n";
    
} catch (PDOException $e) {
    echo "Ошибка: " . $e->getMessage() . "\n";
}
?> 